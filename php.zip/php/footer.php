<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="https://formations.mode83.net/DWAM/dwtl_blog/css/footer.css">
	<title>Outils Télétravail</title>
</head>
<body>


<footer class="footer">
		<!--Faire un rectangle gris qui prend toute la largeur de l'écran-->
		<div class="invisible2">
		<div class="container_footer">
			<div class="geo">
				<img src="https://formations.mode83.net/DWAM/dwtl_blog/img/icone_geo.png" alt="geolocalisation">
				<p>55, avenue du 4 <br> septembre <br> 83300 Draguignan</p>
			</div>	
			<div class="message">
				<img src="https://formations.mode83.net/DWAM/dwtl_blog/img/icone_message.png" alt="messagerie">
				<p>contact@mode83.net</p>
			</div>
			<div class="telephone">
				<img src="https://formations.mode83.net/DWAM/dwtl_blog/img/icone_tel.png" alt="telephone">
				<p>04.94.50.98.90</p>
			</div>
			<div class="reseaux">
				<img src="https://formations.mode83.net/DWAM/dwtl_blog/img/icone_facebook.png" alt="facebook">
				<img src="https://formations.mode83.net/DWAM/dwtl_blog/img/icone_twitter.png" alt="twitter">
				<p>Copyright © 2020 <br> Mode83 <br> Mentions légales</p>
			</div>
		</div>
		</div>

		<div class="container_ancre"><a href="#" class="ancre">↑</a></div>

	</footer>	
</body>
</html>